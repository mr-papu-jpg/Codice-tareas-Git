import { EstadoTareaPipe } from './estado-tarea-pipe';

describe('EstadoTareaPipe', () => {
  it('create an instance', () => {
    const pipe = new EstadoTareaPipe();
    expect(pipe).toBeTruthy();
  });
});
