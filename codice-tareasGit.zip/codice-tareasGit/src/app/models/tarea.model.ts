export interface Tarea {
  descripcion: string;
  completada: boolean;
  fecha: Date;
}
