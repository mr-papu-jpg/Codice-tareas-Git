import { Component } from '@angular/core';

@Component({
  selector: 'app-tarea-form',
  imports: [],
  templateUrl: './tarea-form.html',
  styleUrl: './tarea-form.scss'
})
export class TareaForm {

}
