import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-tarea-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './tarea-form.component.html',
  styleUrls: ['./tarea-form.component.scss']
})
export class TareaFormComponent {
  tareaForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.tareaForm = this.fb.group({
      descripcion: ['', [Validators.required, Validators.minLength(3)]],
      fecha: ['', Validators.required],
      completada: [false]
    });
  }

  crearTarea(): void {
    if (this.tareaForm.valid) {
      console.log('Tarea creada:', this.tareaForm.value);
      this.tareaForm.reset();
    }
  }
}
