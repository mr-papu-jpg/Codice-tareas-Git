import { Component } from '@angular/core';

@Component({
  selector: 'app-lista-tarea',
  imports: [],
  templateUrl: './lista-tarea.html',
  styleUrl: './lista-tarea.scss'
})
export class ListaTarea {

}
