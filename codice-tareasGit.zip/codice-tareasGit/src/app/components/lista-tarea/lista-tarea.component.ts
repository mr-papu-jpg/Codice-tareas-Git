import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-lista-tarea',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lista-tarea.component.html',
  styleUrls: ['./lista-tarea.component.scss']
})
export class ListaTareaComponent {
  tareas = [
    { descripcion: 'Ejemplo de tarea', fecha: '2025-10-01', completada: false }
  ];
}
