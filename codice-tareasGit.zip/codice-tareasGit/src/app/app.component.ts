import { Component, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TareaFormComponent } from './components/tarea-form/tarea-form.component';
import { ListaTareaComponent } from './components/lista-tarea/lista-tarea.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    TareaFormComponent,
    ListaTareaComponent
  ],
  templateUrl: './app.html',
  styleUrls: ['./app.scss']
})
export class App {
  protected readonly title = signal('codice-tareas');
}
